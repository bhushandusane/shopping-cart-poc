package assesment.bhushan.application;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import assesment.bhushan.model.Categories;
import assesment.bhushan.model.Category;
import assesment.bhushan.model.Flatdiscountslabs;
import assesment.bhushan.model.Itemdetail;
import assesment.bhushan.model.ShoppingCart;
import assesment.bhushan.model.Slab;

public class BillApplication
{
	private static Properties properties;
	static
	{
		// THINGS THAT NEED TO BE LOADED AT APPLICATION INITIATION TIMES
		properties = new Properties();
		try
		{
			properties.load(new FileInputStream("./src/main/resources/AppConfig.properties"));
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
	
	HashMap<Integer, Category> storeCategoryWiseDiscounts(String categoryXML)
	{
		HashMap<Integer, Category> categoryMap = null;
		try
		{
			File file = new File(properties.getProperty("resourcesPath") + properties.getProperty(categoryXML));
			// USED JAXB TO PARSE XMLs INTO OBJECTS
			JAXBContext jaxbContext = JAXBContext.newInstance(Categories.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			Categories categories = (Categories) jaxbUnmarshaller.unmarshal(file);
			List<Category> categoryList = categories.getCategory();
			categoryMap = new HashMap<Integer, Category>();
			for (Category cat : categoryList)
			{
				categoryMap.put(cat.getId(), cat);
			}
		}
		catch (JAXBException e)
		{
			e.printStackTrace();
		}
		return categoryMap;
	}
	Double prepareBill(String shoppingCartXML, HashMap<Integer, Category> categoryMap)
	{
		Double totalAmount = 0d;
		try
		{
			Category itemCategory = null;
			Double amount = 0d;
			Double discountedPrice = 0d;
			File file = new File(properties.getProperty("resourcesPath") + properties.getProperty(shoppingCartXML));
			JAXBContext jaxbContext = JAXBContext.newInstance(ShoppingCart.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			ShoppingCart shoppingCart = (ShoppingCart) jaxbUnmarshaller.unmarshal(file);
			// PRINT ITEM WISE DETAILS
			System.out.println("Item \t\t\t\t Quantity \t Unit Price \t Discounted Price \t Amount");
			List<Itemdetail> itemDetailList = shoppingCart.getItemdetails();
			for (Itemdetail itemDetail : itemDetailList)
			{
				itemCategory = categoryMap.get(itemDetail.getItemcategoryid());
				if (itemCategory != null)
				{
					discountedPrice = itemDetail.getUnitprice()
							- (itemDetail.getUnitprice() * itemCategory.getDiscperc() / 100d);
					amount = itemDetail.getQuantity() * discountedPrice;
					totalAmount += amount;
				}
				System.out.println(itemDetail.getItemname() + " \t\t " + itemDetail.getQuantity() + " \t\t "
						+ itemDetail.getUnitprice() + " \t\t " + discountedPrice + " \t\t\t " + amount);
			}
		}
		catch (JAXBException e)
		{
			e.printStackTrace();
		}
		return totalAmount;
	}
	void applyFlatDiscount(Double totalAmount, String flatDiscountSlabsXML)
	{
		if (totalAmount > 0)
		{
			try
			{
				double flatDiscountApplicable = 0d;
				double netBillAmount = 0d;
				File file = new File(
						properties.getProperty("resourcesPath") + properties.getProperty(flatDiscountSlabsXML));
				JAXBContext jaxbContext = JAXBContext.newInstance(Flatdiscountslabs.class);
				Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
				Flatdiscountslabs shoppingCart = (Flatdiscountslabs) jaxbUnmarshaller.unmarshal(file);
				List<Slab> list = shoppingCart.getSlab();
				for (Slab ans : list)
				{
					if (totalAmount > ans.getRangemin())
					{
						if (ans.getRangemax() == null || totalAmount < ans.getRangemax() || ans.getRangemax() == 0)
						{
							flatDiscountApplicable = ans.getDiscperc();
						}
					}
				}
				netBillAmount = (totalAmount * (100d - flatDiscountApplicable)) / 100d;
				System.out.println("\n\nGrand total \t Applicable Discount % \t Net Bill Amount");
				System.out.println(new DecimalFormat("#.00").format(totalAmount) + " \t "
						+ new DecimalFormat("#.00").format(flatDiscountApplicable) + "%\t\t\t "
						+ new DecimalFormat("#.00").format(netBillAmount));
			}
			catch (JAXBException e)
			{
				e.printStackTrace();
			}
		}
	}

}
