package assesment.bhushan.model;

public class Slab
{
	private Double rangemin;
	private Double rangemax;
	private Double discperc;
	public Slab()
	{
		// TODO Auto-generated constructor stub
	}
	public Slab(Double rangemin, Double rangemax, Double discperc)
	{
		this.rangemax = rangemax;
		this.rangemin = rangemin;
		this.discperc = discperc;
	}
	public Double getRangemin()
	{
		return rangemin;
	}
	public void setRangemin(Double rangemin)
	{
		this.rangemin = rangemin;
	}
	public Double getRangemax()
	{
		return rangemax;
	}
	public void setRangemax(Double rangemax)
	{
		this.rangemax = rangemax;
	}
	public Double getDiscperc()
	{
		return discperc;
	}
	public void setDiscperc(Double discperc)
	{
		this.discperc = discperc;
	}
}
