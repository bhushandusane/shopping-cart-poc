package assesment.bhushan.model;

import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Categories {

	List<Category> category;

	public Categories() {
		// TODO Auto-generated constructor stub
	}
	
	public Categories(List<Category> category) {
		super();
		this.category = category;
	}

	public List<Category> getCategory() {
		return category;
	}

	public void setCategory(List<Category> category) {
		this.category = category;
	}
	
}
