package assesment.bhushan.model;

public class Itemdetail
{
	private long itemid;
	private int itemcategoryid;
	private String itemname;
	private double unitprice;
	private int quantity;
	public Itemdetail()
	{
	}
	public Itemdetail(long itemid, int itemcategoryid, String itemname, double unitprice, int quantity)
	{
		super();
		this.itemcategoryid = itemcategoryid;
		this.itemid = itemid;
		this.itemname = itemname;
		this.unitprice = unitprice;
		this.quantity = quantity;
	}
	public long getItemid()
	{
		return itemid;
	}
	public void setItemid(long itemid)
	{
		this.itemid = itemid;
	}
	public int getItemcategoryid()
	{
		return itemcategoryid;
	}
	public void setItemcategoryid(int itemcategoryid)
	{
		this.itemcategoryid = itemcategoryid;
	}
	public String getItemname()
	{
		return itemname;
	}
	public void setItemname(String itemname)
	{
		this.itemname = itemname;
	}
	public double getUnitprice()
	{
		return unitprice;
	}
	public void setUnitprice(double unitprice)
	{
		this.unitprice = unitprice;
	}
	public int getQuantity()
	{
		return quantity;
	}
	public void setQuantity(int quantity)
	{
		this.quantity = quantity;
	}
}
