package assesment.bhushan.model;

import java.util.List;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Categoryndiscount
{
	List<Category> categories;
	List<Slab> flatdiscountslabs;
	public Categoryndiscount()
	{
		// TODO Auto-generated constructor stub
	}
	public Categoryndiscount(List<Category> categories, List<Slab> flatdiscountslabs)
	{
		super();
		this.categories = categories;
		this.flatdiscountslabs = flatdiscountslabs;
	}
	@XmlElement
	public List<Category> getCategories()
	{
		return categories;
	}
	public void setCategories(List<Category> categories)
	{
		this.categories = categories;
	}
	@XmlElement
	public List<Slab> getFlatdiscountslabs()
	{
		return flatdiscountslabs;
	}
	public void setFlatdiscountslabs(List<Slab> flatdiscountslabs)
	{
		this.flatdiscountslabs = flatdiscountslabs;
	}
}
