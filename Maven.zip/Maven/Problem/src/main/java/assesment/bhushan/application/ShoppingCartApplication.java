package assesment.bhushan.application;

public class ShoppingCartApplication
{
	public static void main(String[] args)
	{
		System.out.println("Software Engineer Smart Shopping Cart Problem\n");
		BillApplication billApp = new BillApplication();
		billApp.storeCategoryWiseDiscounts();
		billApp.prepareBill();
		billApp.applyFlatDiscount();
	}
}
