package assesment.bhushan.application;

import java.util.HashMap;
import assesment.bhushan.model.Category;

public class ShoppingCartApplication
{
	public static void main(String[] args)
	{
		System.out.println("Software Engineer Smart Shopping Cart Problem\n");
		// INITILIZE APPLICATION
		BillApplication billApp = new BillApplication();
		
		// STORE CATEGORY WISE DISCOUNTS IN A MAP: AS PER REQUIREMENT, WE CAN EVEN CACHE IT
		HashMap<Integer, Category> categoryMap = billApp.storeCategoryWiseDiscounts(Constants.CATEGORYXML);
		
		// TAKE INPUTS IN XML FORMAT AND PASS IT TO SOME SERVICE TO RECIEVE OUTPUTS. 
		Double totalAmount = billApp.prepareBill(Constants.SHOPPINGCARTXML, categoryMap);
		
		// PRINT THE FINAL OUTPUT
		billApp.applyFlatDiscount(totalAmount, Constants.FLATDISCOUNTSLABSXML);
	}
}
