package assesment.bhushan.application;

public class Constants
{
	public static String SHOPPINGCARTXML = "shoppingCartXML";
	public static String CATEGORYXML = "categoryXML";
	public static String FLATDISCOUNTSLABSXML = "flatdiscountslabsXML";
}
