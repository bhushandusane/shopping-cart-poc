package assesment.bhushan.model;

public class Category
{
	private Integer id;
	private String name;
	private Double discperc;
	public Category()
	{
		// TODO Auto-generated constructor stub
	}
	public Category(int id, String name, double discperc)
	{
		super();
		this.id = id;
		this.name = name;
		this.discperc = discperc;
	}
	public Integer getId()
	{
		return id;
	}
	public void setId(Integer id)
	{
		this.id = id;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public Double getDiscperc()
	{
		return discperc;
	}
	public void setDiscperc(Double discperc)
	{
		this.discperc = discperc;
	}
}
