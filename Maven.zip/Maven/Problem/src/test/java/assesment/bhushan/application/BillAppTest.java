package assesment.bhushan.application;

import org.junit.Test;
import assesment.bhushan.model.Category;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.Assert.assertEquals;
import java.text.DecimalFormat;
import java.util.HashMap;
import org.hamcrest.collection.IsMapContaining;


public class BillAppTest
{
	@Test
	public void test()
	{
		BillApplication billApp = new BillApplication();
		HashMap<Integer, Category> categoryMap = billApp.storeCategoryWiseDiscounts(Constants.CATEGORYXML);
		
		assertThat(categoryMap, IsMapContaining.hasKey(1));  
	}
	
	@Test
	public void totalTest()
	{
		BillApplication billApp = new BillApplication();
		HashMap<Integer, Category> categoryMap = billApp.storeCategoryWiseDiscounts(Constants.CATEGORYXML);
		
		assertEquals(new Double(1634.20), new Double(new DecimalFormat("##.##").format((billApp.prepareBill(Constants.SHOPPINGCARTXML, categoryMap)))));
	}
}
